﻿namespace WebApp.Entity
{
    public class TaskInformation
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public int? UpdatedBy { get; set; }

        //navigation
        public TaskUserLink TaskUserLink { get; set; }
    }
}