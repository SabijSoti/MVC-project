﻿namespace WebApp.Entity
{
    public class TaskUserLink
    {
        public int Id { get; set; }
        public int TaskInformationId { get; set; }
        public int ApplicationUserId { get; set; }
        public int TaskStatusId { get; set; }
        public DateTime? StartedAt { get; set; }
        public DateTime? EndAt { get; set; }

        //navigation properties
        public ApplicationUser ApplicationUser { get; set; }
        public TaskInformation TaskInformation { get; set; }
    }
}