﻿using Microsoft.AspNetCore.Identity;

namespace WebApp.Entity
{
	public class ApplicationUser : IdentityUser<int>
    {
	}
}