﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using WebApp.Constant;
using WebApp.Context;
using WebApp.Entity;
using WebApp.Enum;
using WebApp.Models;

namespace WebApp.Service
{
    public interface ITaskService
    {
        Task StartById(int id);
        Task EndById(int id);
        Task CreateTask(AddTaskRequestModel model);
        Task<List<GetTaskRequestModel>> GetAll(string username);
    }

    public class TaskService : ITaskService
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        public TaskService(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager
        )
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task CreateTask(AddTaskRequestModel model)
        {
            //save task
            var taskInformation = new TaskInformation
            {
                Name = model.Name,
                Description = model.Description,
                CreatedAt = DateTime.UtcNow,
                CreatedBy = 1
            };
            _context.TaskInformations.Add(taskInformation);
            await _context.SaveChangesAsync();

            //save taskuser link
            foreach (var assignTo in model.AssignTo)
            {
                var taskUserLink = new TaskUserLink
                {
                    TaskInformationId = taskInformation.Id,
                    ApplicationUserId = assignTo,
                    TaskStatusId = (int)TaskStatusEnum.Created
                };
                _context.ChangeTracker.Clear();
                _context.TaskUserLinks.Add(taskUserLink);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<GetTaskRequestModel>> GetAll(string username)
        {
            var tasks = new List<TaskUserLink>();
            var user = await _context.Users.Where(x => x.Email.ToLower() == username.ToLower()).FirstOrDefaultAsync();
            var roles = await _userManager.GetRolesAsync(user);

            if (roles.Select(x => x.ToLower()).FirstOrDefault() == RolesConstant.Admin.ToLower())
            {
                return (from tul in _context.TaskUserLinks
                        join ti in _context.TaskInformations on tul.TaskInformationId equals ti.Id
                        join u in _context.Users on tul.ApplicationUserId equals u.Id
                        select new GetTaskRequestModel
                        {
                            Id = tul.Id,
                            Name = ti.Name,
                            Description = ti.Description,
                            StartDate = tul.StartedAt,
                            EndDate = tul.EndAt,
                            TaskStatusId = tul.TaskStatusId,
                            AssignedTo = u.UserName
                        }).ToList();
            }
            else
            {
                return (from tul in _context.TaskUserLinks
                        join ti in _context.TaskInformations on tul.TaskInformationId equals ti.Id
                        join u in _context.Users on tul.ApplicationUserId equals u.Id
                        where u.Id == user.Id
                        select new GetTaskRequestModel
                        {
                            Id = tul.Id,
                            Name = ti.Name,
                            Description = ti.Description,
                            StartDate = tul.StartedAt,
                            EndDate = tul.EndAt,
                            TaskStatusId = tul.TaskStatusId,
                            AssignedTo = u.UserName
                        }).ToList();
            }
        }

        public async Task StartById(int id)
        {
            var taskUserLink = await _context.TaskUserLinks.Where(x => x.Id == id).FirstOrDefaultAsync();
            taskUserLink.StartedAt = DateTime.UtcNow;
            taskUserLink.TaskStatusId = (int)TaskStatusEnum.InProgress;
            await _context.SaveChangesAsync();
        }

        public async Task EndById(int id)
        {
            var taskUserLink = await _context.TaskUserLinks.Where(x => x.Id == id).FirstOrDefaultAsync();
            taskUserLink.EndAt = DateTime.UtcNow;
            taskUserLink.TaskStatusId = (int)TaskStatusEnum.End;
            await _context.SaveChangesAsync();
        }
    }
}