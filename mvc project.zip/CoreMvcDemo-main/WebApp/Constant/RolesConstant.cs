﻿namespace WebApp.Constant
{
    public static class RolesConstant
    {
        public static string Admin = nameof(Admin);
        public static string Employee = nameof(Employee);
    }
}
