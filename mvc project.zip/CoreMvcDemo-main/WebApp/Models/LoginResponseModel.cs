﻿namespace WebApp.Models
{
    public class LoginResponseModel
    {
        public string ErrorMessage { get; set; }
    }
}