﻿namespace WebApp.Enum
{
    public enum TaskStatusEnum
    {
        Created = 1,
        InProgress = 2,
        End = 3
    }
}