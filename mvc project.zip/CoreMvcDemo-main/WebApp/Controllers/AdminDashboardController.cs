﻿using Microsoft.AspNetCore.Builder.Extensions;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebApp.Constant;
using WebApp.Entity;
using WebApp.Models;
using WebApp.Service;

namespace WebApp.Controllers
{
    public class AdminDashboardController : Controller
    {
        private readonly ITaskService _taskService;
        private readonly UserManager<ApplicationUser> _userManager;
        public AdminDashboardController(ITaskService taskService, UserManager<ApplicationUser> userManager)
        {
            _taskService = taskService;
            _userManager = userManager;
        }
        public async Task<IActionResult> Index()
        {
            var username = User.Identity.Name;
            var list = await _taskService.GetAll(username);
            return View(list);
        }

        public async Task<IActionResult> CreateTask()
        {
            var employees = await _userManager.GetUsersInRoleAsync(RolesConstant.Employee);
            return View(new AddTaskRequestModel
            {
                ApplicationUsers = new SelectList(employees, nameof(ApplicationUser.Id), nameof(ApplicationUser.UserName))
            });
        }

        [HttpPost]
        public async Task<IActionResult> CreateTask([FromForm] AddTaskRequestModel model)
        {
            await _taskService.CreateTask(model);
            return RedirectToAction("Index");
        }



     //   [HttpGet]
     //   public IActionResult Details(int? id)
       // {
         //   ApplicationDbContext.AdminDashboard.FirstOrDefaultAsync
           //   return View();
        //}



    }
}