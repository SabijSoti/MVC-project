﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using WebApp.Models;
using Microsoft.AspNetCore.Identity;
using WebApp.Context;
using WebApp.Entity;
using Microsoft.EntityFrameworkCore;
using System.Data;
using WebApp.Constant;

namespace WebApp.Controllers
{

    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        public AccountController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager
        )
        {
            _context = context;
            _userManager = userManager;
            _signInManager = signInManager;
        }

        [HttpGet]
        public IActionResult GetLogin()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> PostLogin([FromForm] LoginRequestModel model)
        {
            if (ModelState.IsValid)
            {
                var responseModel = new LoginResponseModel();
                var user = await _context.Users.Where(x => x.Email == model.UserName).FirstOrDefaultAsync();
                if (user == null)
                {
                    ViewBag.LoginFailedError = "User not found";
                    return View("GetLogin");
                }

                var signInResult = await _signInManager.PasswordSignInAsync(model.UserName, model.Password, isPersistent: false, lockoutOnFailure: false);
                if (signInResult.Succeeded)
                {
                    var assignedRoles = await _userManager.GetRolesAsync(user);
                    var role = assignedRoles.FirstOrDefault();

                    var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Role, role),
                };

                    var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var authProperties = new AuthenticationProperties
                    {
                        ExpiresUtc = DateTime.Now.AddMinutes(10),
                    };
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);
                    return RedirectToAction("Index", "Home");
                }

                ViewBag.LoginFailedError = "Username of Password doesnot match";
                return View("GetLogin");
            }
            else return View("GetLogin");
        }


        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register([FromForm] AddEmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                if(model.Password != model.ConfirmPassword)
                {
                    ViewBag.ErrorMessage = "Password and Conform Password should match.";
                    return View();
                }

                var newUser = new ApplicationUser { Email = model.Email, UserName = model.Email, EmailConfirmed = true };
                var createUserResponse = await _userManager.CreateAsync(newUser, model.Password);
                if (!createUserResponse.Succeeded)
                {
                    ViewBag.ErrorMessage = createUserResponse.Errors.FirstOrDefault()?.Description;
                    return View();
                }

                var addRoleResponse = await _userManager.AddToRoleAsync(newUser, RolesConstant.Employee);
                if (!addRoleResponse.Succeeded)
                {
                    ViewBag.ErrorMessage = addRoleResponse.Errors.FirstOrDefault()?.Description;
                    return View();
                }

                return RedirectToAction("GetLogin");
            }
            return View();
        }


        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            foreach (var cookie in Request.Cookies.Keys)
            {
                Response.Cookies.Delete(cookie);
            }
            return RedirectToAction("Index", "Home");
        }
    }
}