﻿using Microsoft.AspNetCore.Mvc;
using WebApp.Service;

namespace WebApp.Controllers
{
    public class EmployeeDashboardController : Controller
    {
        private readonly ITaskService _taskService;
        public EmployeeDashboardController(ITaskService taskService)
        {
            _taskService = taskService;
        }
        public async Task<IActionResult> Index()
        {
            var username = User.Identity.Name;
            var list = await _taskService.GetAll(username);
            return View(list);
        }

        [HttpGet]
        public async Task<IActionResult> Start([FromRoute] int id)
        {
            await _taskService.StartById(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> End([FromRoute] int id)
        {
            await _taskService.EndById(id);
            return RedirectToAction("Index");
        }
    }
}