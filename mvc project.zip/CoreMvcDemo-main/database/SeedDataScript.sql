﻿--//SEED DEFAULT USERS
IF NOT EXISTS (SELECT * FROM [dbo].[AspNetUsers]  WHERE [UserName] = 'admin@gmail.com')
BEGIN
	INSERT INTO [dbo].[AspNetUsers] ([UserName],[NormalizedUserName],[Email],[NormalizedEmail], [EmailConfirmed],[PhoneNumberConfirmed],[TwoFactorEnabled],[LockoutEnabled],[AccessFailedCount], [PasswordHash], [SecurityStamp]) VALUES 
	('admin@gmail.com','ADMIN@GMAIL.COM', 'admin@gmail.com','ADMIN@GMAIL.COM', 1, 1, 0, 0, 0, 'AQAAAAEAACcQAAAAEBr/wcAPW9vkZEjRqr3nO4Dad3br5KTttPIEXi5XkZWMaS+J1uCcUM4lWpp5dBgCjw==', '27KRQBTZRUKFX6J7OFCEM6BN2N3CNXR4')
END
IF NOT EXISTS (SELECT * FROM [dbo].[AspNetUsers]  WHERE [UserName] = 'employee@gmail.com')
BEGIN
	INSERT INTO [dbo].[AspNetUsers] ([UserName],[NormalizedUserName],[Email],[NormalizedEmail], [EmailConfirmed],[PhoneNumberConfirmed],[TwoFactorEnabled],[LockoutEnabled],[AccessFailedCount], [PasswordHash], [SecurityStamp]) VALUES 
	('employee@gmail.com','EMPLOYEE@GMAIL.COM', 'employee@gmail.com','EMPLOYEE@GMAIL.COM', 1, 1, 0, 0, 0, 'AQAAAAEAACcQAAAAEBr/wcAPW9vkZEjRqr3nO4Dad3br5KTttPIEXi5XkZWMaS+J1uCcUM4lWpp5dBgCjw==', '27KRQBTZRUKFX6J7OFCEM6BN2N3CNXR4')
END
IF NOT EXISTS (SELECT * FROM [dbo].[AspNetUsers]  WHERE [UserName] = 'employee1@gmail.com')
BEGIN
	INSERT INTO [dbo].[AspNetUsers] ([UserName],[NormalizedUserName],[Email],[NormalizedEmail], [EmailConfirmed],[PhoneNumberConfirmed],[TwoFactorEnabled],[LockoutEnabled],[AccessFailedCount], [PasswordHash], [SecurityStamp]) VALUES 
	('employee1@gmail.com','EMPLOYEE1@GMAIL.COM', 'employee1@gmail.com','EMPLOYEE1@GMAIL.COM', 1, 1, 0, 0, 0, 'AQAAAAEAACcQAAAAEBr/wcAPW9vkZEjRqr3nO4Dad3br5KTttPIEXi5XkZWMaS+J1uCcUM4lWpp5dBgCjw==', '27KRQBTZRUKFX6J7OFCEM6BN2N3CNXR4')
END

--//SEED DEFAULT ROLES
IF NOT EXISTS (SELECT * FROM [dbo].[AspNetRoles]  WHERE [Name] = 'Admin')
BEGIN
	INSERT INTO [dbo].[AspNetRoles] ([Name], [NormalizedName], [ConcurrencyStamp]) VALUES ('Admin', 'ADMIN', '23458bff-2a31-7f31-652c-b0ee510e7f6d')
END
IF NOT EXISTS (SELECT * FROM [dbo].[AspNetRoles]  WHERE [Name] = 'Employee')
BEGIN
	INSERT INTO [dbo].[AspNetRoles] ([Name], [NormalizedName], [ConcurrencyStamp]) VALUES ('Employee', 'EMPLOYEE', '02458bfb-1a30-4f32-452a-a0ee910e6f6d')
END

--//SEED DEFAULT USER ROLES
IF NOT EXISTS (SELECT * FROM [dbo].[AspNetUserRoles]  WHERE [UserId] = (SELECT Id FROM [dbo].[AspNetUsers] WHERE [UserName]='admin@gmail.com'))
BEGIN
	INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) 
	VALUES ((SELECT Id FROM [dbo].[AspNetUsers] WHERE [UserName]='admin@gmail.com'), (SELECT Id FROM [dbo].[AspNetRoles] WHERE [Name]='Admin'))
END
IF NOT EXISTS (SELECT * FROM [dbo].[AspNetUserRoles]  WHERE [UserId] = (SELECT Id FROM [dbo].[AspNetUsers] WHERE [UserName]='employee@gmail.com'))
BEGIN
	INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) 
	VALUES ((SELECT Id FROM [dbo].[AspNetUsers] WHERE [UserName]='employee@gmail.com'), (SELECT Id FROM [dbo].[AspNetRoles] WHERE [Name]='EMPLOYEE'))
END
IF NOT EXISTS (SELECT * FROM [dbo].[AspNetUserRoles]  WHERE [UserId] = (SELECT Id FROM [dbo].[AspNetUsers] WHERE [UserName]='employee1@gmail.com'))
BEGIN
	INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) 
	VALUES ((SELECT Id FROM [dbo].[AspNetUsers] WHERE [UserName]='employee1@gmail.com'), (SELECT Id FROM [dbo].[AspNetRoles] WHERE [Name]='EMPLOYEE'))
END
